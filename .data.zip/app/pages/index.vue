<script setup>
const { data, pending, error } = await useFetch('/api/movies/popular')





</script>


<template>

  <div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae eveniet harum, aperiam repellat labore tenetur consectetur quas vitae beatae debitis quaerat asperiores ipsa, distinctio quidem neque necessitatibus odit. Voluptate, assumenda!</p>
    <p v-if="pending"> در حال دریافت </p>

    <p v-else-if="error">خطا در دریافت اطلاعات</p>

    <div v-else>
      <div v-for="movie in data.results" :key="movie.id">
        {{ movie.title }}
      </div>


    </div>


  

  </div>



</template>
