<template>
    <section>
<header >


<slot />


    <nav>

        <NuxtLink to="/"       class="">Home</NuxtLink>
        <NuxtLink to="/movies" class="">Movies</NuxtLink>
        <NuxtLink to="/series" class="">Series</NuxtLink>

    </nav>
</header>
    </section>




</template>





<script setup>




</script>